export const generateId = (): string => {
  return crypto.randomUUID();
};
